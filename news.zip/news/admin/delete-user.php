<?php

include "config.php";

include "role.php";

$userid = $_GET['id'];

$sql = "DELETE FROM user WHERE user_id = {$userid}";

if(mysqli_query($conn, $sql)){
    header("Location: {$hostname}/admin/users.php");
}else{
    echo "<p style = 'color:Red;text-align:center;margin: 10px 0;'>Can not delete.</p>";
}

mysqli_close($conn);

?>