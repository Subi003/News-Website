<?php
$hostname = "http://localhost/news";

$conn = mysqli_connect("localhost","root","","news-site") or die("Connection Failed.." . mysqli_connect_error());

?>