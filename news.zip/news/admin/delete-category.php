<?php

include "config.php";

include "role.php";

$category_id = $_GET['id'];

$sql = "DELETE FROM category WHERE category_id = {$category_id}";

if(mysqli_query($conn, $sql)){
    header("Location: {$hostname}/admin/category.php");
}else{
    echo "<p style = 'color:Red;text-align:center;margin: 10px 0;'>Can not delete.</p>";
}

mysqli_close($conn);

?>